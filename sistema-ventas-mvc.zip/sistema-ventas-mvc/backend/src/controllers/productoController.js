//Controller maneja los req y res -- es teoría
import {listarProductos, registrarProducto} from "../models/productoModel.js"

export const obtenerProductos = async (req, res) => {
    try {
        const productos = await listarProductos();
        res.json(productos);
    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensaje: "Error al obtener los productos"
        });
    };
};

export const crearProducto = async ()